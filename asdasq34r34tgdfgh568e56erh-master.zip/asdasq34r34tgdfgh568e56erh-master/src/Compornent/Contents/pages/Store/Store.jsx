import React from "react";

const Store = () => {
  return <div>Store입니다.</div>;
};

export default Store;
