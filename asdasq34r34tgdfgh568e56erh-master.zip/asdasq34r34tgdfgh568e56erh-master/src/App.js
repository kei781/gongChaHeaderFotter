import "./App.css";
import Layout from "./Compornent/Layout";
import React from "react";

function App() {
  return <Layout />;
}

export default App;
