import React from "react";

const Event = () => {
  return <div>Event입니다.</div>;
};

export default Event;
