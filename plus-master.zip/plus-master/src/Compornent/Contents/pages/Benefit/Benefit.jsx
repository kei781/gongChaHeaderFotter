import React from "react";

const Benefit = () => {
  return <div>Benefit입니다.</div>;
};

export default Benefit;
