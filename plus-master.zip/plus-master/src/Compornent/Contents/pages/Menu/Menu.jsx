import React from "react";

const Menu = () => {
  return <div>Menu입니다.</div>;
};

export default Menu;
